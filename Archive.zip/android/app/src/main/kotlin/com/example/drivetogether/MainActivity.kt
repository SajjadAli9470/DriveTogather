package com.example.drivetogether

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
